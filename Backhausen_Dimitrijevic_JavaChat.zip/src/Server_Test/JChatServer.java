package Server_Test;

public class JChatServer {
	public static void main(String[] args){
		ServerConection server = null;
	         server = new ServerConection(2233);
	}
}
