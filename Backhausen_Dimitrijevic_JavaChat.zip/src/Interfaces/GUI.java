package Interfaces;

public interface GUI {
	public String getInput();
	public void setInput(String t);

}
