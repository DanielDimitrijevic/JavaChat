package Interfaces;
/**
 * Gibt an was ein GUI f�r methoden haben muss
 * @author Dominik, Dimitrijevic
 *
 */
public interface GUI {
	public String getInput();
	public void setInput(String t);

}
